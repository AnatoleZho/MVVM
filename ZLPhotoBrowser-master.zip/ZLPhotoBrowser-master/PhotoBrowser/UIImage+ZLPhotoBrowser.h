//
//  UIImage+ZLPhotoBrowser.h
//  ZLPhotoBrowser
//
//  Created by long on 2017/12/23.
//  Copyright © 2017年 long. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (ZLPhotoBrowser)

- (UIImage*)rotate:(UIImageOrientation)orient;

@end

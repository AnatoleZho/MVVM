//
//  ZLProgressHUD.h
//  ZLPhotoBrowser
//
//  Created by long on 16/2/15.
//  Copyright © 2016年 long. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZLProgressHUD : UIView

- (void)show;

- (void)hide;

@end

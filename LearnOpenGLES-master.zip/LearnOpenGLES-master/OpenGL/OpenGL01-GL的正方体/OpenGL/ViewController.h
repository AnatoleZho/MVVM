//
//  ViewController.h
//  OpenGL
//
//  Created by 林伟池 on 16/8/10.
//  Copyright © 2016年 林伟池. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end


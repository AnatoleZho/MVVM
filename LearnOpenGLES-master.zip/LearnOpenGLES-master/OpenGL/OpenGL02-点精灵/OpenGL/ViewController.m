//
//  ViewController.m
//  OpenGL
//
//  Created by 林伟池 on 16/8/10.
//  Copyright © 2016年 林伟池. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

@end

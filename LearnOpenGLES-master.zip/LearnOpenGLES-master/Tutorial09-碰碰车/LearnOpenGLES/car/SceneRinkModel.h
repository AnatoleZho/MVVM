//
//  SceneRinkModel.h
//  OpenGLES_Ch6_1
//

#import "SceneModel.h"

@interface SceneRinkModel : SceneModel

@end

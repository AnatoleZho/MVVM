//
//  SceneCarModel.h
//  OpenGLES_Ch6_1
//

#import "SceneModel.h"

@interface SceneCarModel : SceneModel

@end

//
//  LYVideoCompostion.h
//  LearnAVFoundation
//
//  Created by loyinglin on 2017/8/22.
//  Copyright © 2017年 林伟池. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface LYVideoCompostion : NSObject <AVVideoCompositing>

@end

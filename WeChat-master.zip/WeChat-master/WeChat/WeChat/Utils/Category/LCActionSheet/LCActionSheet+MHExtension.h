//
//  LCActionSheet+MHExtension.h
//  WeChat
//
//  Created by senba on 2017/5/22.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "LCActionSheet.h"

@interface LCActionSheet (MHExtension)
+ (void)mh_configureActionSheet;
@end

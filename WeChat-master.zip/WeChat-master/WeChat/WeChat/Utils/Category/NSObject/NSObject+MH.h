//
//  NSObject+MH.h
//  WeChat
//
//  Created by senba on 2017/8/4.
//  Copyright © 2017年 Senba. All rights reserved.
//

#ifndef NSObject_MH_h
#define NSObject_MH_h

#import "NSObject+MHExtension.h"
#import "NSObject+MHAlert.h"

#endif /* NSObject_MH_h */

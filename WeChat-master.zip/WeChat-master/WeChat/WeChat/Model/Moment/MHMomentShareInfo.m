//
//  MHMomentShareInfo.m
//  WeChat
//
//  Created by senba on 2018/2/1.
//  Copyright © 2018年 CoderMikeHe. All rights reserved.
//

#import "MHMomentShareInfo.h"

@implementation MHMomentShareInfo

@end

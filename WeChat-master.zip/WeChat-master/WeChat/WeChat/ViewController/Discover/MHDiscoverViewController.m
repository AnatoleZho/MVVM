//
//  MHDiscoverViewController.m
//  WeChat
//
//  Created by senba on 2017/9/11.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHDiscoverViewController.h"

@interface MHDiscoverViewController ()

@end

@implementation MHDiscoverViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

@end

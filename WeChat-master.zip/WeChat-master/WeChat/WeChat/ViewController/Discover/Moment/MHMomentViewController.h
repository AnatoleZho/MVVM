//
//  MHMomentViewController.h
//  WeChat
//
//  Created by senba on 2017/12/20.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  朋友圈

#import "MHTableViewController.h"
#import "MHMomentViewModel.h"
@interface MHMomentViewController : MHTableViewController

@end

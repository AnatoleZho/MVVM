//
//  MHDiscoverViewController.h
//  WeChat
//
//  Created by senba on 2017/9/11.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  `发现`模块

#import "MHCommonViewController.h"
#import "MHDiscoverViewModel.h"
@interface MHDiscoverViewController : MHCommonViewController

@end

//
//  MHFeatureSignatureViewController.h
//  WeChat
//
//  Created by senba on 2017/9/21.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  个性签名

#import "MHViewController.h"
#import "MHFeatureSignatureViewModel.h"
@interface MHFeatureSignatureViewController : MHViewController

@end

//
//  MHFreeInterruptionViewController.h
//  WeChat
//
//  Created by senba on 2017/12/11.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHTableViewController.h"
#import "MHFreeInterruptionViewModel.h"
@interface MHFreeInterruptionViewController : MHTableViewController

@end

//
//  MHAccountSecurityViewController.m
//  WeChat
//
//  Created by senba on 2017/12/7.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHAccountSecurityViewController.h"

@interface MHAccountSecurityViewController ()
/// viewModel
@property (nonatomic, readonly, strong) MHAccountSecurityViewModel *viewModel;
@end

@implementation MHAccountSecurityViewController

@dynamic viewModel;

- (void)viewDidLoad {
    [super viewDidLoad];
    
}


@end

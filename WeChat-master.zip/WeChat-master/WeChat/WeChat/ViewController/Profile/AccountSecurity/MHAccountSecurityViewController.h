//
//  MHAccountSecurityViewController.h
//  WeChat
//
//  Created by senba on 2017/12/7.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  账号安全

#import "MHCommonViewController.h"
#import "MHAccountSecurityViewModel.h"

@interface MHAccountSecurityViewController : MHCommonViewController

@end

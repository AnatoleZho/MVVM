//
//  MHMobileLoginViewController.h
//  WeChat
//
//  Created by senba on 2017/9/27.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  手机号 密码登录 或者  验证码登录

#import "MHLoginBaseViewController.h"
#import "MHMobileLoginViewModel.h"
@interface MHMobileLoginViewController : MHLoginBaseViewController

@end

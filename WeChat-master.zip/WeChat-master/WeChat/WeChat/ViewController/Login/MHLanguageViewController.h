//
//  MHLanguageViewController.h
//  WeChat
//
//  Created by senba on 2017/10/13.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  语言选择

#import "MHTableViewController.h"
#import "MHLanguageViewModel.h"
@interface MHLanguageViewController : MHTableViewController



@end

//
//  MHAddFriendsViewController.h
//  WeChat
//
//  Created by senba on 2017/9/22.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  添加朋友
#import "MHCommonViewController.h"
#import "MHAddFriendsViewModel.h"

@interface MHAddFriendsViewController : MHCommonViewController

@end

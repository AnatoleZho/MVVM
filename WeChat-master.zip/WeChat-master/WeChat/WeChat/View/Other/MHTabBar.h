//
//  MHTabBar.h
//  WeChat
//
//  Created by senba on 2017/9/15.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  自定义系统的TabBar，解决TabBar顶部的细线高度问题

#import <UIKit/UIKit.h>

@interface MHTabBar : UITabBar

@end

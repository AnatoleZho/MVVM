//
//  MHButton.h
//  WeChat
//
//  Created by senba on 2017/10/19.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  去掉高亮状态的按钮

#import <UIKit/UIKit.h>

@interface MHButton : UIButton

@end

//
//  MHButton.m
//  WeChat
//
//  Created by senba on 2017/10/19.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHButton.h"

@implementation MHButton
/// 去掉高亮状态
- (void)setHighlighted:(BOOL)highlighted {}

@end

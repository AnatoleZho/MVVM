//
//  MHMomentCommentCell.m
//  MHDevelopExample
//
//  Created by senba on 2017/7/13.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHMomentCommentCell.h"
#import "MHMomentCommentItemViewModel.h"

@interface MHMomentCommentCell ()

/// viewModel
@property (nonatomic, readwrite, strong) MHMomentCommentItemViewModel *viewModel;
@end

@implementation MHMomentCommentCell
@dynamic viewModel;



@end

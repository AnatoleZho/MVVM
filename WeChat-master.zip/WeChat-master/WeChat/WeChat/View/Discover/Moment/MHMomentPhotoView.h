//
//  MHMomentPhotoView.h
//  MHDevelopExample
//
//  Created by senba on 2017/7/12.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  单张图片

#import "MHControl.h"
#import "MHReactiveView.h"
@interface MHMomentPhotoView : MHControl<MHReactiveView>

@end

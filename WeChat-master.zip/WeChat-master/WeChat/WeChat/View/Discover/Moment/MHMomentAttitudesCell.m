//
//  MHMomentAttitudesCell.m
//  MHDevelopExample
//
//  Created by senba on 2017/7/13.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHMomentAttitudesCell.h"
#import "MHMomentAttitudesItemViewModel.h"

@interface MHMomentAttitudesCell ()
/// viewModel
@property (nonatomic, readwrite, strong) MHMomentAttitudesItemViewModel *viewModel;

@end

@implementation MHMomentAttitudesCell
@dynamic viewModel;




@end

//
//  MHMomentVideoView.h
//  WeChat
//
//  Created by senba on 2018/2/2.
//  Copyright © 2018年 CoderMikeHe. All rights reserved.
//  短视频的View

#import <UIKit/UIKit.h>
#import "MHReactiveView.h"
@interface MHMomentVideoView : UIView<MHReactiveView>
+ (instancetype)videoView;
@end

//
//  MHMomentAttitudesCell.h
//  MHDevelopExample
//
//  Created by senba on 2017/7/13.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  点赞cell

#import "MHMomentContentCell.h"

@interface MHMomentAttitudesCell : MHMomentContentCell
@end

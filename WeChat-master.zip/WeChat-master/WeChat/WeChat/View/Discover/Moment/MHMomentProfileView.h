//
//  MHMomentProfileView.h
//  MHDevelopExample
//
//  Created by senba on 2017/7/13.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  当前用户信息View

#import <UIKit/UIKit.h>
#import "MHReactiveView.h"
@interface MHMomentProfileView : UIView<MHReactiveView>

@end

//
//  MHMomentCommentCell.h
//  MHDevelopExample
//
//  Created by senba on 2017/7/13.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  评论cell

#import "MHMomentContentCell.h"
@interface MHMomentCommentCell : MHMomentContentCell



@end

//
//  MHMomentMessageTipsView.h
//  MHDevelopExample
//
//  Created by senba on 2017/7/14.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  消息提醒view

#import <UIKit/UIKit.h>
#import "MHReactiveView.h"
@interface MHMomentMessageTipsView : UIButton <MHReactiveView>
+ (instancetype) messageTipsView;
@end

//
//  MHProfileInfoZoneCell.h
//  WeChat
//
//  Created by senba on 2018/1/29.
//  Copyright © 2018年 CoderMikeHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MHProfileInfoZoneCell : UITableViewCell
+ (instancetype)cellWithTableView:(UITableView *)tableView;
@end
